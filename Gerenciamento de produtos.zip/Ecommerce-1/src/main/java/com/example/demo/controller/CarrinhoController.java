package com.example.demo.controller;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.ItemVenda;
import com.example.demo.entity.Produto;
import com.example.demo.entity.Venda;
import com.example.demo.repository.ProdutoRepository;
import com.example.demo.repository.VendaRepository;

@RestController
@RequestMapping("/carrinho")
public class CarrinhoController {

    private List<ItemCarrinho> carrinho = new ArrayList<>();
    
    @Autowired
    private ProdutoRepository produtoRepository;
    
    @Autowired
    private VendaRepository vendaRepository;

    // Adicionar produto ao carrinho
    @PostMapping("/adicionar/{id}")
    public ResponseEntity<String> adicionarProdutoAoCarrinho(@PathVariable Long id, @RequestParam Integer quantidade) {
        Produto produto = produtoRepository.findById(id).orElse(null);
        if (produto == null || produto.getQuantidadeEstoque() < quantidade) {
            return ResponseEntity.badRequest().body("Produto não encontrado ou estoque insuficiente.");
        }

        // Verificar se o produto já está no carrinho
        for (ItemCarrinho item : carrinho) {
            if (item.getProduto().getId().equals(id)) {
                item.setQuantidade(item.getQuantidade() + quantidade);
                return ResponseEntity.ok("Produto adicionado ao carrinho.");
            }
        }

        // Caso não esteja no carrinho, adiciona um novo item
        carrinho.add(new ItemCarrinho(produto, quantidade));
        return ResponseEntity.ok("Produto adicionado ao carrinho.");
    }

    // Listar itens do carrinho
    @GetMapping("/itens")
    public List<ItemCarrinho> listarItens() {
        return carrinho;
    }
    
 
    @PostMapping("/finalizar")
    public ResponseEntity<String> finalizarVenda() {
        if (carrinho.isEmpty()) {
            return ResponseEntity.badRequest().body("Carrinho vazio.");
        }

        Venda venda = new Venda();
        venda.setDataVenda(LocalDateTime.now());

        List<ItemVenda> itensVenda = new ArrayList<>();
        double total = 0;

        for (ItemCarrinho item : carrinho) {
            Produto produto = item.getProduto();
            int novaQuantidade = produto.getQuantidadeEstoque() - item.getQuantidade();
            if (novaQuantidade < 0) {
                return ResponseEntity.badRequest().body("Estoque insuficiente.");
            }

            produto.setQuantidadeEstoque(novaQuantidade);
            produtoRepository.save(produto);

            ItemVenda itemVenda = new ItemVenda();
            itemVenda.setProduto(produto);
            itemVenda.setQuantidade(item.getQuantidade());
            itemVenda.setPrecoUnitario(produto.getPreco());

            itensVenda.add(itemVenda);
            total += produto.getPreco() * item.getQuantidade();
        }

        venda.setItens(itensVenda);
        venda.setTotal(total);
        vendaRepository.save(venda);

        carrinho.clear();
        return ResponseEntity.ok("Venda finalizada. Total: R$ " + total);
    }


    // Remover item do carrinho
    @DeleteMapping("/remover/{id}")
    public ResponseEntity<String> removerProduto(@PathVariable Long id) {
        carrinho.removeIf(item -> item.getProduto().getId().equals(id));
        return ResponseEntity.ok("Produto removido do carrinho.");
    }
    
    
    
    @GetMapping("/historico")
    public ResponseEntity<List<Venda>> listarHistoricoVendas() {
        return ResponseEntity.ok(vendaRepository.findAll());
    }

    
    static class ItemCarrinho {
        private Produto produto;
        private int quantidade;

        public ItemCarrinho(Produto produto, int quantidade) {
            this.produto = produto;
            this.quantidade = quantidade;
        }

        public Produto getProduto() {
            return produto;
        }

        public void setProduto(Produto produto) {
            this.produto = produto;
        }

        public int getQuantidade() {
            return quantidade;
        }

        public void setQuantidade(int quantidade) {
            this.quantidade = quantidade;
        }
    }
}
